l=['Network','Bio','Programming','Physics','Music']
for x in l:
    if x[0]=='B':
        print(x)