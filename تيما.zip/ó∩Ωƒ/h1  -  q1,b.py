print('enter number')
x=int(input())
s=0
while(x!=-1):
    s=s+x
    x=int(input())
print(s)    